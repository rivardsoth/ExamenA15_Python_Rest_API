document.getElementById('creer').addEventListener('click', function () {
    var codeProjet = document.getElementById('codeProjet').value;
    var description = document.getElementById('description').value;
    saveProjet(codeProjet, description);
});

function saveProjet(codeProjet, description) {
    fetch('http://localhost:5050/projet', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ Code_Projet: codeProjet, Description: description })
    })
    .then(response => response.json())
    .then(data => {
        var Result = document.getElementById('Result');
        if (data.error) {
            Result.textContent = 'Error: ' + data.error;
        } else {
            Result.textContent = data.message;
        }
    })
    .catch(error => {
        console.error('Error:', error);
    });
}