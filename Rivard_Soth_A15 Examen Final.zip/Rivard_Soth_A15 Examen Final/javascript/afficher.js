var btnAfficher = document.getElementById("btnAfficher")
var btnReset = document.getElementById("reset")

btnReset.addEventListener('click',function(){
    let tableauVoiture = document.getElementById('tableProjet')

          tableauVoiture.innerHTML = ''
})

btnAfficher.addEventListener('click', function(){

    fetch('http://localhost:5050/afficherTout', {
      method: 'GET',
      headers: {
          'Content-Type': 'application/json'
      }
  })
      .then((response) => {
        return response.json();
      })
      .then((donnee) => {
          /*let titre = document.getElementById('titre')
          titre.innerHTML = 'il y a ' + donnee.length + 'donnees dans la BD' */
          let tableauVoiture = document.getElementById('tableProjet')

          tableauVoiture.innerHTML = ''
        
          let selvar = document.getElementById('InputValue').value
          var compteur = 0
          donnee.forEach((temp) => {
            if (selvar === "*") {
                compteur++
                let ligne = document.createElement("tr");
                //creer la colonne code projet
                let colonneId = document.createElement("td");
                colonneId.innerHTML = temp.id;

                //creer la colonne code projet
                let colonneCode = document.createElement("td");
                colonneCode.innerHTML = temp.Code_Projet;

                //ecrire la colonne description
                let colDescription = document.createElement("td");
                colDescription.innerHTML = temp.Description;


                //append pour affichage
                ligne.appendChild(colonneId)
                ligne.appendChild(colonneCode)
                ligne.appendChild(colDescription)
                tableauVoiture.appendChild(ligne)
            }
            else {
              if (selvar === temp.id.toString() || selvar === temp.Code_Projet || selvar === temp.Description) {
                compteur++
                //creer la 1ere ligne
                let ligne = document.createElement("tr");
                //creer la colonne code projet
                let colonneId = document.createElement("td");
                colonneId.innerHTML = temp.id;

                //creer la colonne code projet
                let colonneCode = document.createElement("td");
                colonneCode.innerHTML = temp.Code_Projet;

                //ecrire la colonne description
                let colDescription = document.createElement("td");
                colDescription.innerHTML = temp.Description;


                //append pour affichage
                ligne.appendChild(colonneId)
                ligne.appendChild(colonneCode)
                ligne.appendChild(colDescription)
                tableauVoiture.appendChild(ligne)

              }
            }

          })
          if (compteur === 0){
            let titre = document.getElementById('titre')
            titre.innerHTML = 'Aucune donnée ne corespond à la recherche dans la BD!!'
          }
          else {
            let titre = document.getElementById('titre')
            titre.innerHTML = ''
          }
      })


})